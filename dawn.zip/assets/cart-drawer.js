class CartDrawer extends HTMLElement {
  constructor() {
    super();

    this.addEventListener('keyup', (evt) => evt.code === 'Escape' && this.close());
    this.querySelector('#CartDrawer-Overlay').addEventListener('click', this.close.bind(this));
    this.setHeaderCartIconAccessibility();
  }

  setHeaderCartIconAccessibility() {
    const cartLink = document.querySelector('#cart-icon-bubble');
    cartLink.setAttribute('role', 'button');
    cartLink.setAttribute('aria-haspopup', 'dialog');
    cartLink.addEventListener('click', (event) => {
      event.preventDefault();
      this.open(cartLink);
    });
    cartLink.addEventListener('keydown', (event) => {
      if (event.code.toUpperCase() === 'SPACE') {
        event.preventDefault();
        this.open(cartLink);
      }
    });
  }

  async open(triggeredBy) {
    await this.initUpsell();
    this.openDrawer(triggeredBy);
  }

  async initUpsell(triggeredBy) {
    let upSellContainer = document.querySelector('.product-upsell');
    if (!upSellContainer) return false;
    if (document.querySelector('#product-upsell__collection')) {
      upsellSliderFlickity = new Flickity('#product-upsell__collection', {
        cellAlign: 'left',
        pageDots: true,
        prevNextButtons: true,
      });
      this.openDrawer(triggeredBy);
    } else if (document.querySelector('#product-upsell__cart') || document.querySelector('#product-upsell__product')) {
      this.openDrawer(triggeredBy);
    } else if (document.querySelector('#product-upsell__recommendations').classList.contains('slide-done')) {
      this.openDrawer(triggeredBy);
    } else {
      let upsellSlider = document.querySelector('#product-upsell__recommendations');
      upsellSlider.innerHTML = '';

      let recommendProdId = document.querySelectorAll('cart-drawer-items .cart-item')[0].getAttribute('data-id');

      fetch(
        window.Shopify.routes.root +
          `recommendations/products?product_id=${recommendProdId}&limit=4&section_id=upsell-recommendations`
      )
        .then((response) => response.text())
        .then((data) => {
          upsellSlider.innerHTML = data;
          const newUpsellItem = document.querySelectorAll('#shopify-section-upsell-recommendations .grid__item');
          if (newUpsellItem.length > 0) {
            upSellContainer.classList.remove('hidden');
            upsellSliderFlickity = new Flickity('#shopify-section-upsell-recommendations', {
              cellAlign: 'left',
              pageDots: true,
              prevNextButtons: true,
            });
          } else {
            upSellContainer.classList.add('hidden');
          }
        })
        .finally(() => {
          upsellSlider.classList.add('slide-done');
        });
    }
  }

  openDrawer(triggeredBy) {
    if (triggeredBy) this.setActiveElement(triggeredBy);
    const cartDrawerNote = this.querySelector('[id^="Details-"] summary');
    if (cartDrawerNote && !cartDrawerNote.hasAttribute('role')) this.setSummaryAccessibility(cartDrawerNote);
    // here the animation doesn't seem to always get triggered. A timeout seem to help
    const isCartPage = document.body.classList.contains('template-cart');
    if (!isCartPage)
      setTimeout(() => {
        this.classList.add('animate', 'active');
      });

    this.addEventListener(
      'transitionend',
      () => {
        const containerToTrapFocusOn = this.classList.contains('is-empty')
          ? this.querySelector('.drawer__inner-empty')
          : document.getElementById('CartDrawer');
        const focusElement = this.querySelector('.drawer__inner') || this.querySelector('.drawer__close');
        trapFocus(containerToTrapFocusOn, focusElement);
      },
      { once: true }
    );

    if (!isCartPage) document.body.classList.add('overflow-hidden');
  }

  close() {
    this.classList.remove('active');
    removeTrapFocus(this.activeElement);
    document.body.classList.remove('overflow-hidden');
  }

  setSummaryAccessibility(cartDrawerNote) {
    cartDrawerNote.setAttribute('role', 'button');
    cartDrawerNote.setAttribute('aria-expanded', 'false');

    if (cartDrawerNote.nextElementSibling.getAttribute('id')) {
      cartDrawerNote.setAttribute('aria-controls', cartDrawerNote.nextElementSibling.id);
    }

    cartDrawerNote.addEventListener('click', (event) => {
      event.currentTarget.setAttribute('aria-expanded', !event.currentTarget.closest('details').hasAttribute('open'));
    });

    cartDrawerNote.parentElement.addEventListener('keyup', onKeyUpEscape);
  }

  renderContents(parsedState) {
    this.querySelector('.drawer__inner').classList.contains('is-empty') &&
      this.querySelector('.drawer__inner').classList.remove('is-empty');
    this.productId = parsedState.id;
    this.getSectionsToRender().forEach((section) => {
      const sectionElement = section.selector
        ? document.querySelector(section.selector)
        : document.getElementById(section.id);
      sectionElement.innerHTML = this.getSectionInnerHTML(parsedState.sections[section.id], section.selector);
    });

    setTimeout(() => {
      this.querySelector('#CartDrawer-Overlay').addEventListener('click', this.close.bind(this));
      this.open();
      dacRemoveBundleAjax.init();
    });
  }

  renderContentsDrawer() {
    if (window.location.pathname == '/cart') {
      location.reload();
    }

    let self = this;
    fetch('/cart?view=drawer&timestamp=' + Date.now(), {
      credentials: 'same-origin',
      method: 'GET',
    })
      .then(function (content) {
        content.text().then(function (html) {
          document.querySelector('.js-cart-drawer-content').innerHTML = html;

          let countCount = parseInt(document.querySelector('.js-data-cart-count').getAttribute('data-count'), 10);
          document.querySelector('.js-cart-count-bubble .header-cart-count-bubble').innerHTML = countCount;
          if (countCount == 0) {
            document.querySelector('.js-cart-count-bubble').classList.add('hide');
            self.classList.add('is-empty');
          } else {
            document.querySelector('.js-cart-count-bubble').classList.remove('hide');
            self.classList.remove('is-empty');
          }

          self.initUpsell();
          dacRemoveBundleAjax.init();
        });
      })
      .finally(() => {
        setTimeout(() => {
          this.querySelector('#CartDrawer-Overlay').addEventListener('click', this.close.bind(this));
          this.open();
        });
      });
  }

  getSectionInnerHTML(html, selector = '.shopify-section') {
    return new DOMParser().parseFromString(html, 'text/html').querySelector(selector).innerHTML;
  }

  getSectionsToRender() {
    return [
      {
        id: 'cart-drawer',
        selector: '#CartDrawer',
      },
      {
        id: 'cart-icon-bubble',
      },
    ];
  }

  getSectionDOM(html, selector = '.shopify-section') {
    return new DOMParser().parseFromString(html, 'text/html').querySelector(selector);
  }

  setActiveElement(element) {
    this.activeElement = element;
  }
}

customElements.define('cart-drawer', CartDrawer);

class CartDrawerItems extends CartItems {
  getSectionsToRender() {
    return [
      {
        id: 'CartDrawer',
        section: 'cart-drawer',
        selector: '.drawer__inner',
      },
      {
        id: 'cart-icon-bubble',
        section: 'cart-icon-bubble',
        selector: '.shopify-section',
      },
    ];
  }
}

customElements.define('cart-drawer-items', CartDrawerItems);

class RecommendationsAdd extends HTMLElement {
  constructor() {
    super();

    this.cart = document.querySelector('cart-notification') || document.querySelector('cart-drawer');
    this.addEventListener('click', this.onButtonClick.bind(this));
  }

  onButtonClick() {
    this.submitButton = this;
    if (this.submitButton.classList.contains('disabled')) return;

    this.submitButton.classList.add('loading');

    let properties = {};
    if (this.getAttribute('data-offer')) {
      properties = { _Offer: this.getAttribute('data-offer') };
    }
    if (this.getAttribute('data-gift')) {
      properties = { _Gift: this.getAttribute('data-gift') };
    }
    let selling_plan = '';
    if (this.getAttribute('data-selling-plan')) {
      selling_plan = this.getAttribute('data-selling-plan');
    }

    fetch(window.Shopify.routes.root + 'cart/add.js', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        items: [
          {
            id: this.getAttribute('data-id'),
            quantity: 1,
            properties: properties,
            selling_plan: selling_plan,
          },
        ],
      }),
    })
      .then((response) => response.json())
      .then((response) => {
        this.cart.renderContentsDrawer();
      })
      .catch((e) => {
        console.error(e);
      })
      .finally(() => {
        this.submitButton.classList.remove('loading');
        if (this.cart && this.cart.classList.contains('is-empty')) this.cart.classList.remove('is-empty');
        this.querySelector('.loading-overlay__spinner').classList.add('hidden');
      });
  }
}

customElements.define('recommendations-add', RecommendationsAdd);

class RecommendationsShowAdd extends HTMLElement {
  constructor() {
    super();

    this.addEventListener('click', this.onButtonClick.bind(this));
  }

  onButtonClick() {
    this.wrap = this.closest('.product-recommendation');
    this.addProduct = this.wrap.querySelector('.product-form-wrap');
    this.infoProduct = this.wrap.querySelector('.product-info-wrap');
    this.titleProduct = this.wrap.querySelector('.cart-item__name');

    this.addProduct.classList.remove('hidden');
    this.infoProduct.classList.add('hidden');
    this.titleProduct.classList.add('hidden');

    setTimeout(() => {
      upsellSliderFlickity.resize();
    }, 100);
  }
}

customElements.define('recommendations-show', RecommendationsShowAdd);

/**
 * Remove Bundle from Cart
 * Using Cart Line Item Key: https://stackoverflow.com/questions/60616697/shopify-remove-change-quantity-of-multiple-cart-items/60622488#60622488
 */
dacRemoveBundleAjax = {
  init: function init() {
    this.cart = document.querySelector('cart-notification') || document.querySelector('cart-drawer');

    const buttons = document.querySelectorAll('[data-dac-delete-bundle]');

    for (var i = 0; i < buttons.length; i++) {
      buttons[i].addEventListener('click', function (e) {
        e.preventDefault();
        const bundleID = this.getAttribute('data-dac-bundle');
        const line = this.getAttribute('data-line-item-key');
        dacRemoveBundleAjax.removeBundle(bundleID, line);
        e.stopPropagation();
      });
    }
  },
  removeBundle: function removeBundle(bundleID, line) {
    const cartItemElements = this.cart.querySelectorAll(`#CartItem-${line} .loading-overlay`);
    const cartDrawerItemElements = this.cart.querySelectorAll(`#CartDrawer-Item-${line} .loading-overlay`);

    [...cartItemElements, ...cartDrawerItemElements].forEach((overlay) => overlay.classList.remove('hidden'));
    const qry = new Array();
    const bundleLines = document.querySelectorAll('[data-dac-bundle="' + bundleID + '"]');

    for (i = 0; i < bundleLines.length; ++i) {
      qry.push('updates[' + bundleLines[i].getAttribute('data-cart-item-key') + ']=0');
    }
    const url = `${routes.cart_update_url}?${qry.join('&')}`;
    fetch(url).then(() => {
      this.cart.renderContentsDrawer();
    });
  },
};

dacRemoveBundleAjax.init();
