dacFreeGift = {
  init: function init() {
    this.cart = document.querySelector('cart-notification') || document.querySelector('cart-drawer');
    this.cartItems = document.querySelector('cart-items') || document.querySelector('cart-drawer-items');

    elementToObserve = document.querySelector('#main-cart-items .js-contents') || document.querySelector('cart-drawer');
    observer = new MutationObserver((mutations) => {
      for (let mutation of mutations) {
        if (
          mutation.target.id == 'CartDrawer' ||
          mutation.target.className == 'drawer__inner js-cart-drawer-content' ||
          mutation.target.className == 'js-contents'
        ) {
          dacFreeGift.check();
        }
      }
    });
    observer.observe(elementToObserve, { childList: true, subtree: true });
  },
  add: function add() {
    console.log('Adding Gift');
    document.getElementById('free-gift').click();
    return Promise.resolve('Added gift');
  },
  remove: function remove(itemKey) {
    console.log('Removing Gift');
    this.cartItems.updateQuantity(itemKey, 0);

    return Promise.resolve('Removed: ' + itemKey);
  },
  check: function check() {
    console.log('Checking Gifts...');
    rg = 'false';
    ag = 'false';
    rg = document.querySelector('#dacCartGiftInfo .remove-gift').innerHTML;
    ag = document.querySelector('#dacCartGiftInfo .add-gift').innerHTML;

    if (rg != 'false') {
      dacFreeGift.remove(rg);
    } else if (ag != 'false') {
      dacFreeGift.add();
    }
  },
};

dacFreeGift.init();
window.onload = function () {
  dacFreeGift.check();
};
