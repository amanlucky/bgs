if (!customElements.get('cross-sell-product')) {
  customElements.define(
    'cross-sell-product',
    class CrossSellProduct extends HTMLElement {
      constructor() {
        super();

        this.selectEl = this.querySelector(`#select-${this.dataset.block}`);
        this.priceEl = this.querySelector(`#price-${this.dataset.block}`);
        this.variantInput = this.querySelector(`[name="id"]`);

        this.variantData = this.variantData || JSON.parse(this.querySelector('[type="application/json"]').textContent);

        this.currentVariantID = this.variantInput.value;
        this.currentVariant = this.variantData.find((variant) => variant.id === this.currentVariantID);

        if (this.selectEl) {
          this.selectEl.addEventListener('change', (e) => {
            this.selectVariant(e);
          });
        }
      }

      selectVariant(e) {
        this.currentVariantID = parseInt(e.target.value);
        this.currentVariant = this.variantData.find((variant) => variant.id === this.currentVariantID);

        this.updatePrice();
      }

      updatePrice() {
        this.priceEl.innerHTML = Shopify.formatMoney(this.currentVariant.price);
      }
    }
  );
}
