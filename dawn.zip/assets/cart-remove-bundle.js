/**
 * Remove Bundle from Cart
 * Using Cart Line Item Key: https://stackoverflow.com/questions/60616697/shopify-remove-change-quantity-of-multiple-cart-items/60622488#60622488
 */
dacRemoveBundle = {
  init: function init() {
    const buttons = document.querySelectorAll('[data-dac-delete-bundle]');

    for (var i = 0; i < buttons.length; i++) {
      buttons[i].addEventListener('click', function (e) {
        e.preventDefault();
        const bundleID = this.getAttribute('data-dac-bundle');
        dacRemoveBundle.removeBundle(bundleID);
        e.stopPropagation();
      });
    }
  },
  removeBundle: function removeBundle(bundleID) {
    const qry = new Array();
    const bundleLines = document.querySelectorAll('[data-dac-bundle="' + bundleID + '"]');

    for (i = 0; i < bundleLines.length; ++i) {
      qry.push('updates[' + bundleLines[i].getAttribute('data-cart-item-key') + ']=0');
    }

    if (qry.length > 0) {
      window.location.replace('https://drannacabeca.com/cart/update?' + qry.join('&amp;'));
    }
  },
};

dacRemoveBundle.init();
